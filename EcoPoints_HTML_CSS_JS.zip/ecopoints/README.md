# EcoPoints (HTML/CSS/JavaScript)

## Run
Open the folder using VS Code Live Server, or from a terminal run `python -m http.server 8000` and visit `http://localhost:8000`. Camera scanning works on localhost or HTTPS, with camera permission. The QR scanning library is loaded from a CDN and needs internet on first use.

## Features
- Responsive dashboard with approved balance, pending potential points, waste categories
- Photo upload and phone camera capture
- Working camera QR scanner and QR-image file scanner using html5-qrcode
- QR token generation and one-time claim checks
- Admin demo approval/rejection, reward redemption (rice and groceries)
- IndexedDB database, record tables, JSON export and import
- JavaScript OOP: EcoDatabase and EcoApp classes, constructors, methods, objects, arrays

## Important limits
This HTML/CSS/JS-only project stores data in **IndexedDB**, not MySQL. Each browser/device has its own local database. Demo admin actions and QR token creation are intentionally unprotected; they are not suitable for real-world reward distribution. In production, use a backend such as PHP/MySQL or a hosted database with authenticated users/admins and server-side point/token validation. QR images are generated using an external QR image service, which receives the token value. Use test tokens only.
